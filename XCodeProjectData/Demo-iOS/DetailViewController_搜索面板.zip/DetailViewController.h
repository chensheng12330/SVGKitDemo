//
//  DetailViewController.h
//  iOSDemo
//
//  Created by adam on 29/09/2012.
//  Copyright (c) 2012 na. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SVGKit.h"
#import "SVGKImage.h"
#import "NIDropDown.h"

@interface DetailViewController : UIViewController <SVGKImageDelegate ,NIDropDownDelegate, UIScrollViewDelegate,UISearchBarDelegate>

@property (nonatomic, retain) IBOutlet UIScrollView *scrollViewForSVG;
@property (nonatomic, retain) IBOutlet SVGKImageView *contentView;
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView *viewActivityIndicator;
@property (retain, nonatomic) IBOutlet UISearchBar *SearchBar;

/*!
 载入数据
 */
- (void)loadResource:(NSString *)name;

- (IBAction)animate:(id)sender;


@end
