//
//  DetailViewController.m
//  iOSDemo
//
//  Created by adam on 29/09/2012.
//  Copyright (c) 2012 na. All rights reserved.
//
#import "DetailViewController.h"
#import "MasterViewController.h"
#import "NodeList+Mutable.h"
#import "SVGKFastImageView.h"
#import "SHSVGTool.h"


@interface DetailViewController ()

@property (nonatomic, assign) SVGKImage *svgImage;
@property (nonatomic, retain) SHSVGTool *svgTool;

@property (nonatomic, retain) CALayer *tapLayer;
@property (nonatomic, retain) UITapGestureRecognizer* tapGestureRecognizer;

@property (nonatomic, retain) NIDropDown *dropDown;

- (void)loadResource:(NSString *)name;

@property (nonatomic, retain) NSArray *allKeys;
@end


@implementation DetailViewController

- (void)dealloc {

	self.scrollViewForSVG = nil;
	self.contentView = nil;
	self.viewActivityIndicator = nil;
	self.dropDown = nil;
    self.allKeys  = nil;
    
    [_SearchBar release];
	[super dealloc];
}

-(void)viewDidLoad
{
    
    if([self respondsToSelector:@selector(edgesForExtendedLayout)]) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    
	//self.navigationItem.rightBarButtonItems = [NSArray arrayWithObjects:[[[UIBarButtonItem alloc] initWithTitle:@"Debug" style:UIBarButtonItemStyleBordered target:self action:@selector(showHideBorder:)] autorelease],[[[UIBarButtonItem alloc] initWithTitle:@"Animate" style:UIBarButtonItemStyleBordered target:self action:@selector(animate:)] autorelease],nil];
}

-(NSString*) layerInfo:(CALayer*) l
{
	return [NSString stringWithFormat:@"%@:%@", [l class], NSStringFromCGRect(l.frame)];
}

//
-(void) handleTapGesture1:(UITapGestureRecognizer*) recognizer
{
    CGPoint p = [recognizer locationInView:self.contentView];
    
    CALayer*   layerForHitTesting;
	SVGKImage* svgImage = nil;
    
	if( [self.contentView isKindOfClass:[SVGKFastImageView class]])
	{
		layerForHitTesting = ((SVGKFastImageView*)self.contentView).image.CALayerTree;
		svgImage = ((SVGKFastImageView*)self.contentView).image;
		
		CGSize scaleConvertImageToViewForHitTest = CGSizeMake( self.contentView.bounds.size.width / svgImage.size.width, self.contentView.bounds.size.height / svgImage.size.height ); // this is a copy/paste of the internal "SCALING" logic used in SVGKFastImageView
		
		p = CGPointApplyAffineTransform( p, CGAffineTransformInvert( CGAffineTransformMakeScale( scaleConvertImageToViewForHitTest.width, scaleConvertImageToViewForHitTest.height)) ); // must do the OPPOSITE of the zoom (to convert the 'seeming' point to the 'actual' point
	}
	else{ layerForHitTesting = self.contentView.layer;}
	
	
    //****  Set showTap layer;
	CALayer* hitLayer = [layerForHitTesting hitTest:p];
    NSLog(@"%@ - %@",hitLayer,hitLayer.name);
    
    //--1 judge layer type
    if ([hitLayer isKindOfClass:NSClassFromString(@"CAShapeLayerWithHitTest")]) {
        if (hitLayer.name == NULL || [hitLayer.name isEqualToString:@""]) {
            return;
        }
    }
    else if ([hitLayer isKindOfClass:NSClassFromString(@"CATextLayer")])
    {
        //CALayer *layer = [self.svgImage.CALayerTree valueForKey:kSVGElementIdentifier];
        NSLog(@"%@",hitLayer.name);
        NSString *layerId = hitLayer.name;
        
        if (layerId) {
            CALayer *layer = [self.svgTool getRectLayerByID:layerId];
            if (layer) {[self showTapLayer:layer];}
        }
        
        return;
    }
    else
    {
        return;
    }
    
    [self showTapLayer:hitLayer];
    return;
}
//

-(void) showTapLayer:(CALayer*) hitLayer
{
    //--2 add tab layer
    if (self.tapLayer)
    {
        if ([self.tapLayer.name isEqualToString:hitLayer.name]) {
            return;
        }
        
        [self.tapLayer removeFromSuperlayer];
    }
    
    self.tapLayer = [[[CALayer alloc] init] autorelease];
    self.tapLayer.frame = CGRectMake(0, 0, hitLayer.frame.size.width, hitLayer.frame.size.height);
    self.tapLayer.backgroundColor = [UIColor colorWithRed:1 green:0 blue:0 alpha:0.5].CGColor;
    self.tapLayer.name = hitLayer.name;
    
    [hitLayer addSublayer:self.tapLayer];
    [self.contentView setNeedsDisplay];

}


#pragma mark - CRITICAL: this method makes Apple render SVGs in sharp focus

-(void)scrollViewDidEndZooming:(UIScrollView *)scrollView withView:(UIView *)view atScale:(float)finalScale
{
	/** NB: very important! The "finalScale" paramter to this method is SLIGHTLY DIFFERENT from the scale that Apple reports in the other delegate methods
	 
	 This is very confusing, clearly it's bit of a hack - the other methods get called
	 at slightly the wrong time, and so their data is slightly wrong (out-by-one animation step).
	 
	 ONLY the values passed as params to this method are correct!
	 */
	
	/**
	 
	 Apple's implementation of zooming is EXTREMELY poorly designed; it's a hack onto a class
	 that was only designed to do panning (hence the name: uiSCROLLview)
	 
	 So ... "zooming" via a UIScrollView is NOT integrated with UIView
	 rendering - in a UIView subclass, you CANNOT KNOW whether you have been "zoomed"
	 (i.e.: had your view contents ruined horribly by Apple's class)
	 
	 The three lines that follow are - allegedly - Apple's preferred way of handling
	 the situation. Note that we DO NOT SET view.frame! According to official docs,
	 view.frame is UNDEFINED (this is very worrying, breaks a huge amount of UIKit-related code,
	 but that's how Apple has documented / implemented it!)
	 */
	view.transform = CGAffineTransformIdentity; // this alters view.frame! But *not* view.bounds
	view.bounds = CGRectApplyAffineTransform( view.bounds, CGAffineTransformMakeScale(finalScale, finalScale));
	[view setNeedsDisplay];
	
	/**
	 Workaround for another bug in Apple's hacks for UIScrollView:
	 
	  - when you reset the transform, as advised by Apple, you "break" Apple's memory of the scroll factor.
	     ... because they "forgot" to store it anywhere (they read your view.transform as if it were a private
			 variable inside UIScrollView! This causes MANY bugs in applications :( )
	 */
	self.scrollViewForSVG.minimumZoomScale /= finalScale;
	self.scrollViewForSVG.maximumZoomScale /= finalScale;
}

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return self.contentView;
}

#pragma mark - rest of class

- (void)loadResource:(NSString *)name
{
	[self.viewActivityIndicator startAnimating];
    
	[[NSRunLoop mainRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.01]]; // makes the animation appear
	
	SVGKImageView* newContentView = nil;
    
	CGSize customSizeForImage = CGSizeZero;
	{
		SVGKImage *document = nil;
		
		/** Detect URL vs file */
		if( [name hasPrefix:@"http://"]) //URL Load
		{
			document = [SVGKImage imageWithContentsOfURL:[NSURL URLWithString:name]];
		}
		else //local Load
        {
			document = [SVGKImage imageNamed:[name stringByAppendingPathExtension:@"svg"]];
        }
		
        BOOL shouldScaleTimesTwo = NO;
		if( shouldScaleTimesTwo ) document.scale = 2.0;
		
		if( document == nil )
		{
			[[[[UIAlertView alloc] initWithTitle:@"SVG parse failed" message:@"Total failure. See console log" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease] show];
			newContentView = nil; // signals to the rest of this method: the load failed
		}
		else
		{
			if( document.parseErrorsAndWarnings.rootOfSVGTree != nil )
			{
				//NSLog(@"[%@] Freshly loaded document (name = %@) has size = %@", [self class], name, NSStringFromCGSize(document.size) );
				
				/** NB: the SVG Spec says that the "correct" way to upscale or downscale an SVG is by changing the
				 SVG Viewport. SVGKit automagically does this for you if you ever set a value to image.scale */
				if( ! CGSizeEqualToSize( CGSizeZero, customSizeForImage ) )
					document.size = customSizeForImage; // preferred way to scale an SVG! (standards compliant!)
				
				newContentView = [[[SVGKFastImageView alloc] initWithSVGKImage:document] autorelease];
                ((SVGKFastImageView*)newContentView).disableAutoRedrawAtHighestResolution = TRUE;
			}
			else
			{
				[[[[UIAlertView alloc] initWithTitle:@"SVG parse failed" message:[NSString stringWithFormat:@"%i fatal errors, %i warnings. First fatal = %@",[document.parseErrorsAndWarnings.errorsFatal count],[document.parseErrorsAndWarnings.errorsRecoverable count]+[document.parseErrorsAndWarnings.warnings count], ((NSError*)[document.parseErrorsAndWarnings.errorsFatal objectAtIndex:0]).localizedDescription] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease] show];
				newContentView = nil; // signals to the rest of this method: the load failed
			}
		}
	}
	
	if( newContentView != nil )
	{
		/**
		 * NB: at this point we're guaranteed to have a "new" replacemtent ready for self.contentView
		 */
		
		/** Move the gesture recognizer off the old view */
		if( self.contentView != nil  && self.tapGestureRecognizer != nil ) {
            [self.contentView removeGestureRecognizer:self.tapGestureRecognizer];
        }
		
		[self.contentView removeFromSuperview];
		
		/******* swap the new contentview in ************/
		self.contentView = newContentView;
		
	
		/** set the border for new item */
		self.contentView.showBorder = FALSE;
	
		/** Move the gesture recognizer onto the new one */	
		if( self.tapGestureRecognizer == nil )
		{
			self.tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTapGesture1:)];
		}
		[self.contentView addGestureRecognizer:self.tapGestureRecognizer];
		
		
		[self.scrollViewForSVG addSubview:self.contentView];
		[self.scrollViewForSVG setContentSize: self.contentView.frame.size];
		
		float screenToDocumentSizeRatio = self.scrollViewForSVG.frame.size.width / self.contentView.frame.size.width;
		
		self.scrollViewForSVG.minimumZoomScale = MIN( 1, screenToDocumentSizeRatio );
		self.scrollViewForSVG.maximumZoomScale = MAX( 1, screenToDocumentSizeRatio );
		
		/**
		 EXAMPLE:
		 
		 How to find particular nodes in the tree, after parsing.
		 
		 In this case, we search for all SVG <g> tags, which usually mean grouped-objects in Inkscape etc:
		 NodeList* elementsUsingTagG = [document.DOMDocument getElementsByTagName:@"g"];
		 NSLog( @"[%@] checking for SVG standard set of elements with XML tag/node of <g>: %@", [self class], elementsUsingTagG.internalArray );
		 */
	}
	
	[self.viewActivityIndicator stopAnimating];
    
    self.svgImage = self.contentView.image;
    self.svgImage.delegate = self;

}

-(void) completeAddAllLayer:(SVGKImage *)svgImage
{
    self.svgTool  = [[[SHSVGTool alloc] initWithSVGKImage:self.svgImage] autorelease];
    NSLog(@"svg Loder OK.");
}


- (IBAction)animate:(id)sender {
    
    /*SVGTool search Text Test2*/
    
    NSString *secText = @"5B25";
    NSDictionary *resDict = [self.svgTool searchStringWithKey:secText];
    NSString *eid = resDict.allKeys[0];
    CALayer *layer = [self.svgTool getRectLayerByID:eid];
     [self showTapLayer:layer];

    
    
    /*  SVGTool Test1
    SHSVGTool *svgTool = [[SHSVGTool alloc] initWithSVGKImage:self.svgImage];
    
    NSString *testStr;
    
    //test <text>
    testStr = [svgTool getTextByID:@"1"];
    testStr = [svgTool getTextByID:@"2"];
    testStr = [svgTool getTextByID:@"3"];
    
    //test <tspan>
    testStr = [svgTool getTextByID:@"11"];
    */
    
    
    return;
    ///////////////////
    
    /*
    SVGDocument* ddoc = self.svgImage.DOMDocument;
    NodeList* rectlist = [ddoc getElementsByTagName:@"rect"];
    NodeList* textlist = [ddoc getElementsByTagName:@"text"];
    SVGElement *elem = [ddoc getElementById:@"1"];
    SVGElement *tspan = [textlist item:10];
     NSMutableString *str = [NSMutableString new];
     for (Node *node in tspan.childNodes) {
     
     NSLog(@"%@",node.textContent);
     if (node.nodeType==DOMNodeType_ELEMENT_NODE) {
     
     //NSString *text = [self stripText:node.textContent];
     [str appendString:node.textContent];
     }
     
     }
    */
    
    /*
     如果 children = 1. 直接获取文字
     如果 children >1   获取字节点文字<tspan>
     */
    
    /*
    NodeList* accumulator = [[[NodeList alloc] init] autorelease];
	[DOMHelperUtilities privateGetElementsByName:@"tspan" inNamespace:nil childrenOfElement:tspan addToList:accumulator];
    */
    
}

- (void)viewDidUnload {
    [self setSearchBar:nil];
    [super viewDidUnload];
}

/*!
 查找
 */
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    
}

/*!
 取消
 */
- (void)searchBarCancelButtonClicked:(UISearchBar *) searchBar
{
    [searchBar resignFirstResponder];
    
    [self.dropDown hideDropDown:(UIButton*)self.SearchBar];
    self.dropDown = nil;
    
    return;
}


- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if (searchText.length<1) { return;}
    
    //1 search text from svg textMap
    NSDictionary *seaDict = [self.svgTool searchStringWithKey:searchText];
    NSArray * arr = [seaDict allValues];
    self.allKeys  = [seaDict allKeys];
    
    if(self.dropDown == nil) {
        CGFloat f = 200;
        self.dropDown = [[NIDropDown alloc] showDropDown:(UIButton*)searchBar height:&f arr:arr];
        self.dropDown.delegate = self;
    }
    else
    {
        [self.dropDown reloadDropDownForData:arr];
    }
    
    return;
}

- (void) niDropDownDelegateMethod: (NIDropDown *) sender text:(NSString*) text
{
    int index = sender.tag;
    NSString *svgEleID = self.allKeys[index];
    CALayer* seaLayer = [self.svgTool getRectLayerByID:svgEleID];
    
    [self showTapLayer:seaLayer];
    
    
    [self.dropDown hideDropDown:(UIButton*)self.SearchBar];
    self.dropDown = nil;
    
    [self.SearchBar resignFirstResponder];
}
@end
